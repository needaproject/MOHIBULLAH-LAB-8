package com.general.scd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScdApplication {
	public static void main(String[] args) {
		SpringApplication.run(ScdApplication.class, args);
	}
}
