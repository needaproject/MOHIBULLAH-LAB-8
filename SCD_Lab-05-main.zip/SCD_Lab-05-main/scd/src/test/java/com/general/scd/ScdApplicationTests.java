package com.general.scd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScdApplicationTests {

	@Test
	void contextLoads() {
	}

}
