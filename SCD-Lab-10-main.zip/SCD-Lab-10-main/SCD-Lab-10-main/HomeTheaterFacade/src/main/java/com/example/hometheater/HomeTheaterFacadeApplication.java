package com.example.hometheater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeTheaterFacadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeTheaterFacadeApplication.class, args);
	}

}
