package com.example.proxypattern.model;

public interface Document {
    String display();
}
