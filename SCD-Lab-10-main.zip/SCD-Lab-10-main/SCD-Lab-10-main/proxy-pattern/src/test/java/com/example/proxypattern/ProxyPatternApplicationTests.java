package com.example.proxypattern;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyPatternApplicationTests {

	@Test
	void contextLoads() {
	}

}
