package com.example.HRSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
