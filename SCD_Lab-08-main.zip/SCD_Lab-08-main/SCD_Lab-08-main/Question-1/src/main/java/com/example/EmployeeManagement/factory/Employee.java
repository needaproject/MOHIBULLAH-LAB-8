package com.example.EmployeeManagement.factory;

public interface Employee {
    String getEmployeeType();
}
